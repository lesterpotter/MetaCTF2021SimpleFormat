#!/bin/bash

cd /fundamentals && ./fundamentals
